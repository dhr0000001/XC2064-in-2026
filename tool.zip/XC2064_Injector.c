#ifndef UNICODE
#define UNICODE
#endif

#include <windows.h>
#include <commctrl.h>
#include <stdio.h>
#include <process.h>
#include <commdlg.h>
#include <shellapi.h>

#pragma comment(lib, "comctl32.lib")
#pragma comment(lib, "shell32.lib")
#pragma comment(lib, "gdi32.lib")
#pragma comment(lib, "comdlg32.lib")

// --- 全局变量 ---
HWND g_hWnd, g_hBtnInject, g_hBtnLoad, g_hBtnExport, g_hBtnAnalyze, g_comboCom, g_editBaud, g_hProg;
HWND g_hEditBin, g_hEditHex, g_hStatus;
char g_current_path[MAX_PATH] = {0};

typedef struct {
    size_t count0, count1;
    BOOL synced;
    unsigned char* data;
    size_t data_len;
} RbtStats;

typedef struct {
    char port[20];
    int baud;
    unsigned char* data;
    size_t len;
} SerialTask;

RbtStats g_last_stats = {0};

// --- 串口探测 ---
void EnumComPorts(HWND hCombo) {
    SendMessage(hCombo, CB_RESETCONTENT, 0, 0);
    for (int i = 1; i <= 30; i++) {
        char path[20]; sprintf(path, "\\\\.\\COM%d", i);
        HANDLE h = CreateFileA(path, GENERIC_READ|GENERIC_WRITE, 0, NULL, OPEN_EXISTING, 0, NULL);
        if (h != INVALID_HANDLE_VALUE || GetLastError() == ERROR_ACCESS_DENIED) {
            wchar_t name[10]; swprintf(name, 10, L"COM%d", i);
            SendMessage(hCombo, CB_ADDSTRING, 0, (LPARAM)name);
            if (h != INVALID_HANDLE_VALUE) CloseHandle(h);
        }
    }
    SendMessage(hCombo, CB_SETCURSEL, 0, 0);
}

// --- 脱壳逻辑 (提取位流) ---
void ProcessRbtFile(const char* path) {
    if (g_last_stats.data) free(g_last_stats.data);
    memset(&g_last_stats, 0, sizeof(RbtStats));
    FILE* f = fopen(path, "r");
    if (!f) return;

    unsigned char* buffer = (unsigned char*)malloc(1024 * 1024);
    char line[1024];
    int sync_bits = 0, bit_acc = 0, bit_cnt = 0;
    
    size_t v_cap = 1024 * 1024;
    char *b_v = (char*)calloc(v_cap, 1), *h_v = (char*)calloc(v_cap, 1);
    size_t bp = 0, hp = 0;

    while (fgets(line, sizeof(line), f)) {
        for (int i = 0; line[i]; i++) {
            char c = line[i];
            if (c != '0' && c != '1') continue;
            if (!g_last_stats.synced) {
                if (c == '1') sync_bits++; else sync_bits = 0;
                if (sync_bits == 8) {
                    g_last_stats.synced = TRUE; g_last_stats.count1 = 8;
                    buffer[g_last_stats.data_len++] = 0xFF;
                    bp += sprintf(b_v + bp, "[SYNC] 11111111 ");
                    hp += sprintf(h_v + hp, "FF ");
                }
            } else {
                if (c == '0') g_last_stats.count0++; else g_last_stats.count1++;
                if (bp < v_cap - 10) {
                    b_v[bp++] = c;
                    if ((g_last_stats.count0 + g_last_stats.count1) % 8 == 0) b_v[bp++] = ' ';
                    if ((g_last_stats.count0 + g_last_stats.count1) % 64 == 0) { b_v[bp++] = '\r'; b_v[bp++] = '\n'; }
                }
                bit_acc = (bit_acc << 1) | (c - '0'); bit_cnt++;
                if (bit_cnt == 8) {
                    unsigned char b = (unsigned char)bit_acc;
                    buffer[g_last_stats.data_len++] = b;
                    if (hp < v_cap - 20) {
                        hp += sprintf(h_v + hp, "%02X ", b);
                        if (g_last_stats.data_len % 16 == 0) hp += sprintf(h_v + hp, "\r\n");
                    }
                    bit_acc = 0; bit_cnt = 0;
                }
            }
        }
    }
    fclose(f); g_last_stats.data = buffer;
    SetWindowTextA(g_hEditBin, b_v); SetWindowTextA(g_hEditHex, h_v);
    free(b_v); free(h_v);
    SetWindowTextW(g_hStatus, L"位流脱壳完成，等待操作...");
}

// --- 强化版：带帧协议与流控的传输线程 ---
unsigned int __stdcall ThreadTransmit(void* arg) {
    SerialTask* task = (SerialTask*)arg;
    HANDLE hSerial = CreateFileA(task->port, GENERIC_READ | GENERIC_WRITE, 0, NULL, OPEN_EXISTING, 0, NULL);
    
    if (hSerial == INVALID_HANDLE_VALUE) {
        MessageBoxW(g_hWnd, L"串口打开失败！请检查端口是否占用或连接线。", L"通信错误", MB_ICONERROR);
        goto end;
    }

    // 1. 串口配置 (保持 8N1 配置)
    DCB dcb = {0};
    dcb.DCBlength = sizeof(dcb);
    if (!GetCommState(hSerial, &dcb)) goto end;
    dcb.BaudRate = task->baud;
    dcb.ByteSize = 8;
    dcb.StopBits = ONESTOPBIT;
    dcb.Parity = NOPARITY;
    dcb.fOutxCtsFlow = FALSE; 
    dcb.fRtsControl = RTS_CONTROL_DISABLE;
    if (!SetCommState(hSerial, &dcb)) goto end;

    COMMTIMEOUTS timeouts = {0};
    timeouts.WriteTotalTimeoutConstant = 500; 
    SetCommTimeouts(hSerial, &timeouts);

    // 2. 定义您的帧协议头尾
    const unsigned char FRAME_HEADER[4] = {0x00, 0x01, 0x02, 0x03};
    const unsigned char FRAME_FOOTER[4] = {0x03, 0x02, 0x01, 0x00};
    DWORD written;

    SetWindowTextW(g_hStatus, L"📡 正在同步协议头...");
    SendMessage(g_hProg, PBM_SETPOS, 0, 0);

    // --- A. 发送帧头 ---
    WriteFile(hSerial, FRAME_HEADER, 4, &written, NULL);
    Sleep(50); // 给下位机状态机切换的时间

    // --- B. 发送主体位流 ---
    for (size_t i = 0; i < task->len; i++) {
        if (!WriteFile(hSerial, &task->data[i], 1, &written, NULL)) {
            SetWindowTextW(g_hStatus, L"❌ 传输中断：串口写入失败");
            break;
        }

        // 分包流控：每 32 字节稍微停顿，防止下位机 ORE 溢出
        if (i % 32 == 0 || i == task->len - 1) {
            Sleep(2); 
            int progress = (int)((i * 100) / task->len);
            SendMessage(g_hProg, PBM_SETPOS, progress, 0);
            
            wchar_t statusText[128];
            swprintf(statusText, 128, L"正在注入位流: %d%% (%zu / %zu Bytes)", progress, i, task->len);
            SetWindowTextW(g_hStatus, statusText);
        }
    }

    // --- C. 发送帧尾 ---
    Sleep(50); 
    WriteFile(hSerial, FRAME_FOOTER, 4, &written, NULL);

    FlushFileBuffers(hSerial);
    Sleep(100);

    SendMessage(g_hProg, PBM_SETPOS, 100, 0);
    SetWindowTextW(g_hStatus, L"✅ 位流注入成功！请点击 [2.开始装载]");
    EnableWindow(g_hBtnLoad, TRUE); // 传输成功才允许装载

end:
    if (hSerial != INVALID_HANDLE_VALUE) CloseHandle(hSerial);
    EnableWindow(g_hBtnInject, TRUE);
    free(task);
    return 0;
}

// --- 动作2：发送 0x5A 加载指令 ---
void SendLoadCommand() {
    wchar_t wCom[20], wBaud[20];
    GetWindowTextW(g_comboCom, wCom, 20);
    GetWindowTextW(g_editBaud, wBaud, 20);
    char port[20]; sprintf(port, "\\\\.\\%ls", wCom);

    HANDLE hSerial = CreateFileA(port, GENERIC_READ | GENERIC_WRITE, 0, NULL, OPEN_EXISTING, 0, NULL);
    if (hSerial == INVALID_HANDLE_VALUE) {
        MessageBoxW(g_hWnd, L"串口连接失败", L"错误", MB_ICONERROR);
        return;
    }

    DCB dcb = {0}; dcb.DCBlength = sizeof(dcb); GetCommState(hSerial, &dcb);
    dcb.BaudRate = _wtoi(wBaud); SetCommState(hSerial, &dcb);
    
    unsigned char cmd = 0x5A;
    DWORD written;
    
    // 关键：发送指令前强制停顿，确保下位机已完成上一帧的清理
    Sleep(20);
    if (WriteFile(hSerial, &cmd, 1, &written, NULL)) {
        SetWindowTextW(g_hStatus, L"🚀 指令下发成功：硬件正在拉动时序...");
    }
    
    CloseHandle(hSerial);
}
// --- 布局 ---
void DoLayout(HWND hwnd) {
    RECT rc; GetClientRect(hwnd, &rc);
    int w = rc.right, h = rc.bottom;
    MoveWindow(g_hStatus, 15, 10, w - 30, 25, TRUE);
    int box_h = (h - 240) / 2;
    MoveWindow(g_hEditBin, 15, 50, w - 30, box_h, TRUE);
    MoveWindow(g_hEditHex, 15, 60 + box_h, w - 30, box_h, TRUE);
    int cy = h - 120;
    MoveWindow(g_hProg, 15, cy, w - 30, 15, TRUE);
    MoveWindow(g_comboCom, 15, cy + 25, 100, 200, TRUE);
    MoveWindow(g_editBaud, 120, cy + 25, 75, 24, TRUE);
    
    int bw = (w - 220) / 4;
    MoveWindow(g_hBtnInject, 210, cy + 25, bw, 60, TRUE);
    MoveWindow(g_hBtnLoad, 210 + bw + 2, cy + 25, bw, 60, TRUE);
    MoveWindow(g_hBtnExport, 210 + (bw + 2) * 2, cy + 25, bw, 60, TRUE);
    MoveWindow(g_hBtnAnalyze, 210 + (bw + 2) * 3, cy + 25, bw, 60, TRUE);
}

LRESULT CALLBACK WndProc(HWND hwnd, UINT msg, WPARAM wp, LPARAM lp) {
    switch (msg) {
        case WM_CREATE: {
            HFONT hf = CreateFontW(14, 0, 0, 0, FW_NORMAL, 0, 0, 0, 0, 0, 0, 0, 0, L"Consolas");
            g_hStatus = CreateWindowW(L"STATIC", L"请拖入 RBT 文件", WS_VISIBLE|WS_CHILD, 0,0,0,0, hwnd, NULL, NULL, NULL);
            g_hEditBin = CreateWindowExW(WS_EX_CLIENTEDGE, L"EDIT", NULL, WS_VISIBLE|WS_CHILD|WS_VSCROLL|ES_MULTILINE|ES_AUTOVSCROLL|ES_READONLY, 0,0,0,0, hwnd, NULL, NULL, NULL);
            g_hEditHex = CreateWindowExW(WS_EX_CLIENTEDGE, L"EDIT", NULL, WS_VISIBLE|WS_CHILD|WS_VSCROLL|ES_MULTILINE|ES_AUTOVSCROLL|ES_READONLY, 0,0,0,0, hwnd, NULL, NULL, NULL);
            SendMessage(g_hEditBin, WM_SETFONT, (WPARAM)hf, TRUE); SendMessage(g_hEditHex, WM_SETFONT, (WPARAM)hf, TRUE);
            g_comboCom = CreateWindowW(L"COMBOBOX", NULL, WS_VISIBLE|WS_CHILD|CBS_DROPDOWNLIST, 0,0,0,0, hwnd, NULL, NULL, NULL); EnumComPorts(g_comboCom);
            g_editBaud = CreateWindowExW(WS_EX_CLIENTEDGE, L"EDIT", L"115200", WS_VISIBLE|WS_CHILD, 0,0,0,0, hwnd, NULL, NULL, NULL);
            g_hProg = CreateWindowExW(0, PROGRESS_CLASSW, NULL, WS_VISIBLE|WS_CHILD, 0,0,0,0, hwnd, NULL, NULL, NULL);
            
            g_hBtnInject = CreateWindowW(L"BUTTON", L"1.传输字节流", WS_VISIBLE|WS_CHILD|WS_DISABLED, 0,0,0,0, hwnd, (HMENU)1, NULL, NULL);
            g_hBtnLoad   = CreateWindowW(L"BUTTON", L"2.开始装载", WS_VISIBLE|WS_CHILD|WS_DISABLED, 0,0,0,0, hwnd, (HMENU)5, NULL, NULL);
            g_hBtnExport = CreateWindowW(L"BUTTON", L"导出 .H", WS_VISIBLE|WS_CHILD|WS_DISABLED, 0,0,0,0, hwnd, (HMENU)2, NULL, NULL);
            g_hBtnAnalyze = CreateWindowW(L"BUTTON", L"Ken 解析", WS_VISIBLE|WS_CHILD|WS_DISABLED, 0,0,0,0, hwnd, (HMENU)4, NULL, NULL);
            DragAcceptFiles(hwnd, TRUE); break;
        }
        case WM_DROPFILES: {
            if (DragQueryFileA((HDROP)wp, 0, g_current_path, MAX_PATH)) {
                ProcessRbtFile(g_current_path);
                EnableWindow(g_hBtnInject, TRUE); EnableWindow(g_hBtnExport, TRUE); EnableWindow(g_hBtnAnalyze, TRUE);
            }
            DragFinish((HDROP)wp); break;
        }
        case WM_COMMAND: {
            if (LOWORD(wp) == 1) { // 传输
                SerialTask* t = (SerialTask*)malloc(sizeof(SerialTask));
                wchar_t wCom[20], wBaud[20]; GetWindowTextW(g_comboCom, wCom, 20); GetWindowTextW(g_editBaud, wBaud, 20);
                sprintf(t->port, "\\\\.\\%ls", wCom); t->baud = _wtoi(wBaud);
                t->data = g_last_stats.data; t->len = g_last_stats.data_len;
                EnableWindow(g_hBtnInject, FALSE); _beginthreadex(NULL, 0, ThreadTransmit, t, 0, NULL);
            }
            if (LOWORD(wp) == 5) { SendLoadCommand(); } // 加载
            if (LOWORD(wp) == 2) { /* 导出逻辑同前... */ }
            if (LOWORD(wp) == 4) { /* Ken 解析逻辑同前... */ }
            break;
        }
        case WM_SIZE: DoLayout(hwnd); break;
        case WM_DESTROY: PostQuitMessage(0); break;
        default: return DefWindowProcW(hwnd, msg, wp, lp);
    }
    return 0;
}

int WINAPI WinMain(HINSTANCE hi, HINSTANCE hp, LPSTR lp, int n) {
    InitCommonControls();
    WNDCLASSW wc = {0}; wc.lpfnWndProc = WndProc; wc.hInstance = hi; wc.lpszClassName = L"XC_TOOL";
    wc.hCursor = LoadCursor(NULL, IDC_ARROW); wc.hbrBackground = (HBRUSH)(COLOR_BTNFACE+1);
    RegisterClassW(&wc);
    g_hWnd = CreateWindowExW(0, wc.lpszClassName, L"XC2064 Analyzer Pro V3.7", WS_OVERLAPPEDWINDOW, 100, 100, 900, 750, NULL, NULL, hi, NULL);
    ShowWindow(g_hWnd, n); MSG m; while (GetMessageW(&m, NULL, 0, 0)) { TranslateMessage(&m); DispatchMessageW(&m); }
    return 0;
}