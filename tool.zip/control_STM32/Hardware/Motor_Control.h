#ifndef __MOTOR_CONTROL_H
#define __MOTOR_CONTROL_H

void NVIC_Configuration(void);

void Control_Init();


#endif
