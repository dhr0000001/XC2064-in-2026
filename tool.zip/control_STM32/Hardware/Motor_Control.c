//XC2064�Ŀ��Ƴ�ʼ��
#include "stm32f10x.h"                  // Device header
#include "Delay.h"
#include "OLED.h"
uint8_t data = 0;
//��ʼ�����裬��Ҫ�ȳ�ʼ���洢��Ȼ���ʼ��оƬ,0��ʲô��û��ʼ��������ϵ0�㣬1Ϊ�洢����ʼ���꣬ע�ⲻҪ��δ������ʼ������Ϣʱ�����κ��µĴ�����Ϣ������ܻ����
//
uint8_t State = 0;

void NVIC_Configuration(void) {
    NVIC_InitTypeDef NVIC_InitStructure;


    NVIC_PriorityGroupConfig(NVIC_PriorityGroup_2);

    NVIC_InitStructure.NVIC_IRQChannel = USART1_IRQn;
    NVIC_InitStructure.NVIC_IRQChannelPreemptionPriority = 1; // ?????
    NVIC_InitStructure.NVIC_IRQChannelSubPriority = 1;        // ?????
    NVIC_InitStructure.NVIC_IRQChannelCmd = ENABLE;
    NVIC_Init(&NVIC_InitStructure);
}

void Control_Init()
{
    GPIO_InitTypeDef GPIO_InitStructure;


    RCC_APB2PeriphClockCmd(RCC_APB2Periph_GPIOB, ENABLE);

    GPIO_InitStructure.GPIO_Pin = GPIO_Pin_10 | GPIO_Pin_11;
    GPIO_InitStructure.GPIO_Mode = GPIO_Mode_Out_PP;
    GPIO_InitStructure.GPIO_Speed = GPIO_Speed_50MHz; 
    GPIO_Init(GPIOB, &GPIO_InitStructure);

    GPIO_ResetBits(GPIOB, GPIO_Pin_11);
		GPIO_SetBits(GPIOB,GPIO_Pin_10);
	
	

    USART_InitTypeDef USART_InitStructure;

    // 1. ?? GPIOA ? USART1 ???
    RCC_APB2PeriphClockCmd(RCC_APB2Periph_GPIOA | RCC_APB2Periph_USART1, ENABLE);

    // 2. PA9 (TX) - ??????
    GPIO_InitStructure.GPIO_Pin = GPIO_Pin_9;
    GPIO_InitStructure.GPIO_Speed = GPIO_Speed_50MHz;
    GPIO_InitStructure.GPIO_Mode = GPIO_Mode_AF_PP; 
    GPIO_Init(GPIOA, &GPIO_InitStructure);

    // 3. PA10 (RX) - ????
    GPIO_InitStructure.GPIO_Pin = GPIO_Pin_10;
    GPIO_InitStructure.GPIO_Mode = GPIO_Mode_IN_FLOATING;
    GPIO_Init(GPIOA, &GPIO_InitStructure);

    // 4. ??????
    USART_InitStructure.USART_BaudRate = 9600;
    USART_InitStructure.USART_WordLength = USART_WordLength_8b;
    USART_InitStructure.USART_StopBits = USART_StopBits_1;
    USART_InitStructure.USART_Parity = USART_Parity_No;
    USART_InitStructure.USART_HardwareFlowControl = USART_HardwareFlowControl_None;
    USART_InitStructure.USART_Mode = USART_Mode_Rx | USART_Mode_Tx;

    USART_Init(USART1, &USART_InitStructure);
    
    USART_ITConfig(USART1, USART_IT_RXNE, ENABLE);
    USART_Cmd(USART1, ENABLE);
}

void USART1_IRQHandler(void) {
    
    if (USART_GetITStatus(USART1, USART_IT_RXNE) != RESET) {
       data = USART_ReceiveData(USART1);
        
			if(data == 0x01){
				//ROM��ʼ��
				if(State == 0){
					GPIO_ResetBits(GPIOB,GPIO_Pin_10);
					Delay_us(100);
					GPIO_SetBits(GPIOB,GPIO_Pin_10);
					Delay_us(100);
					GPIO_ResetBits(GPIOB,GPIO_Pin_10);
					State = 1;
					OLED_ShowString(1,1,"ROM_INIT!");
				}else if(State == 1){
					OLED_ShowString(3,1,"ROM_HAD_INIT!");
				}else{OLED_ShowString(4,1,"ERROR!");}	
			}else if(data == 0x02){
				//XC2064��ʼ��
					if(State == 1){
					GPIO_SetBits(GPIOB,GPIO_Pin_11);
					OLED_ShowString(2,1,"XC2064_INIT!");
					State = 2;
					}else if(State == 2){
					OLED_ShowString(4,1,"XC2064_HAD_INIT!");
					}else{
					OLED_ShowString(4,1,"ERROR!");
					}
			}else if(data == 0x03){
					if(State == 2){
					State =0;
					OLED_ShowString(1,1,"                 ");
					OLED_ShowString(2,1,"                 ");
					OLED_ShowString(3,1,"                 ");
					OLED_ShowString(4,1,"                 ");
					}else{
					OLED_ShowString(1,1,"BIG_ERROR");
					}
			}
    }
}




