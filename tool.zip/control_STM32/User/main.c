#include "stm32f10x.h"
#include "Delay.h"
#include "OLED.h"

/* --- ??? --- */
#define MAX_BUFFER_SIZE 2048
#define CMD_START_LOAD  0x5A

/* ??????:
   CCLK: PA1
   DIN:  PB1
   RST:  PB11
   UART2: PA2(TX), PA3(RX) 
*/
#define CCLK_PIN    GPIO_Pin_1  
#define DIN_PIN     GPIO_Pin_1  
#define RST_PIN     GPIO_Pin_11 

/* --- ???? --- */
volatile uint8_t bitstream[MAX_BUFFER_SIZE];
volatile uint16_t data_len = 0;
volatile uint8_t g_LoadTrigger = 0; 

/* --- 1. ?????? --- */
void Precise_Delay_250ns(void) {
    uint32_t i = 15; 
    while(i--); // 72MHz????15-18???250ns
}

/* --- 2. ??????? (?????) --- */
void Hardware_Init(void) {
    GPIO_InitTypeDef GPIO_InitStructure;
    USART_InitTypeDef USART_InitStructure;
    NVIC_InitTypeDef NVIC_InitStructure;

    // A. ????:GPIOA, GPIOB, ??????, ??2??
    RCC_APB2PeriphClockCmd(RCC_APB2Periph_GPIOA | RCC_APB2Periph_GPIOB | RCC_APB2Periph_AFIO, ENABLE);
    RCC_APB1PeriphClockCmd(RCC_APB1Periph_USART2, ENABLE);

    // B. PA1 (CCLK) ??? - ??????? (Out_PP)
    GPIO_InitStructure.GPIO_Pin = CCLK_PIN;
    GPIO_InitStructure.GPIO_Speed = GPIO_Speed_50MHz;
    GPIO_InitStructure.GPIO_Mode = GPIO_Mode_Out_PP;
    GPIO_Init(GPIOA, &GPIO_InitStructure);
    GPIO_ResetBits(GPIOA, CCLK_PIN); // ?????

    // C. PB1 (DIN) ? PB11 (RST) ???
    GPIO_InitStructure.GPIO_Pin = DIN_PIN | RST_PIN;
    GPIO_Init(GPIOB, &GPIO_InitStructure);
    GPIO_SetBits(GPIOB, RST_PIN); // RST?????

    // D. UART2 ????:PA2(TX)????, PA3(RX)????
    GPIO_InitStructure.GPIO_Pin = GPIO_Pin_2;
    GPIO_InitStructure.GPIO_Mode = GPIO_Mode_AF_PP;
    GPIO_Init(GPIOA, &GPIO_InitStructure);
    
    GPIO_InitStructure.GPIO_Pin = GPIO_Pin_3;
    GPIO_InitStructure.GPIO_Mode = GPIO_Mode_IN_FLOATING;
    GPIO_Init(GPIOA, &GPIO_InitStructure);

    // E. UART2 ????:115200, 8N1
    USART_InitStructure.USART_BaudRate = 4800;
    USART_InitStructure.USART_WordLength = USART_WordLength_8b;
    USART_InitStructure.USART_StopBits = USART_StopBits_1;
    USART_InitStructure.USART_Parity = USART_Parity_No;
    USART_InitStructure.USART_HardwareFlowControl = USART_HardwareFlowControl_None;
    USART_InitStructure.USART_Mode = USART_Mode_Rx | USART_Mode_Tx;
    USART_Init(USART2, &USART_InitStructure);

    // F. ????:???????????
    USART_ITConfig(USART2, USART_IT_RXNE, ENABLE);
    USART_ITConfig(USART2, USART_IT_IDLE, ENABLE);

    NVIC_InitStructure.NVIC_IRQChannel = USART2_IRQn;
    NVIC_InitStructure.NVIC_IRQChannelPreemptionPriority = 0;
    NVIC_InitStructure.NVIC_IRQChannelSubPriority = 0;
    NVIC_InitStructure.NVIC_IRQChannelCmd = ENABLE;
    NVIC_Init(&NVIC_InitStructure);

    USART_Cmd(USART2, ENABLE);
}

/* --- 3. ???????? --- */
const uint8_t FRAME_HEADER[4] = {0x00, 0x01, 0x02, 0x03};
const uint8_t FRAME_FOOTER[4] = {0x03, 0x02, 0x01, 0x00};

typedef enum {
    WAIT_HEADER,
    RECV_DATA,
    WAIT_FOOTER
} RecvState_t;

volatile RecvState_t g_recv_state = WAIT_HEADER;
uint8_t head_idx = 0, foot_idx = 0;
void USART2_IRQHandler(void) {
    if (USART_GetFlagStatus(USART2, USART_FLAG_ORE) != RESET) { USART_ReceiveData(USART2); }

    if (USART_GetITStatus(USART2, USART_IT_RXNE) != RESET) {
        uint8_t res = USART_ReceiveData(USART2);

        // --- ??:0x5A ????????? ---
        if (res == 0x5A && data_len > 100) {
            g_LoadTrigger = 1;
            return;
        }

        // --- ????? ---
        switch (g_recv_state) {
            case WAIT_HEADER: // ???? 00 01 02 03
                if (res == FRAME_HEADER[head_idx]) {
                    head_idx++;
                    if (head_idx == 4) {
                        g_recv_state = RECV_DATA;
                        data_len = 0; // ????,???????
                        head_idx = 0;
                    }
                } else { head_idx = 0; }
                break;

            case RECV_DATA: // ????,??????
                if (res == FRAME_FOOTER[foot_idx]) {
                    foot_idx++;
                    if (foot_idx == 4) { // ???? 03 02 01 00
                        g_recv_state = WAIT_HEADER;
                        foot_idx = 0;
                        // ?? data_len ?????? 03 02 01,????
                        data_len -= 3; 
                        // ??????,??? OLED ?? Ready
                    } else {
                        if (data_len < MAX_BUFFER_SIZE) bitstream[data_len++] = res;
                    }
                } else {
                    // ????????,????????????????
                    for(uint8_t k=0; k<foot_idx; k++) {
                        if (data_len < MAX_BUFFER_SIZE) bitstream[data_len++] = FRAME_FOOTER[k];
                    }
                    foot_idx = 0;
                    if (data_len < MAX_BUFFER_SIZE) bitstream[data_len++] = res;
                }
                break;
        }
    }
}

/* --- 4. ???????? --- */
void XC2064_Execute_Physical_Load(void) {
    // A. ????
    GPIO_ResetBits(GPIOB, RST_PIN);   
    GPIOA->BRR = CCLK_PIN; // PA1??
    Delay_ms(20);
    GPIO_SetBits(GPIOB, RST_PIN);     
    Delay_us(500);

    // B. ????
    for (uint16_t i = 0; i < data_len; i++) {
        uint8_t byte = bitstream[i];
        for (int b = 0; b < 8; b++) {
            // DIN
            if (byte & (0x80 >> b)) GPIO_SetBits(GPIOB, DIN_PIN);
            else GPIO_ResetBits(GPIOB, DIN_PIN);

            Precise_Delay_250ns();

            // CCLK (PA1) ??
            GPIOA->BSRR = CCLK_PIN; // ??
            Precise_Delay_250ns();
            Precise_Delay_250ns();
            GPIOA->BRR = CCLK_PIN;  // ??
            Precise_Delay_250ns();
        }
    }

    // C. ????
    for (int i = 0; i < 100; i++) {
        GPIOA->BSRR = CCLK_PIN; Precise_Delay_250ns();
        GPIOA->BRR = CCLK_PIN; Precise_Delay_250ns();
    }
}

/* --- 5. ??? --- */
int main(void) {
    SystemInit();
    OLED_Init();
    Hardware_Init(); 

    OLED_ShowString(1, 1, "XC2064 Loader");
    OLED_ShowString(2, 1, "Len: 0");

    uint16_t last_len = 0;

    while (1) {
        // ?????????OLED,?????????
        if (data_len != last_len) {
            OLED_ShowNum(2, 6, data_len, 4);
            last_len = data_len;
        }

        if (g_LoadTrigger) {
            OLED_Clear();
            OLED_ShowString(1, 1, "Programming...");
            XC2064_Execute_Physical_Load();
            
            OLED_ShowString(2, 1, "Load Success!");
            g_LoadTrigger = 0;
            data_len = 0;
            last_len = 0;
            
            Delay_s(3);
            OLED_Clear();
            OLED_ShowString(1, 1, "XC2064 Loader");
            OLED_ShowString(2, 1, "Len: 0");
        }
    }
}